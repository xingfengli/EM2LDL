import os
import pickle
import copy
import argparse
import torch
import numpy as np
import torch.nn.functional as F
from torch.autograd import Variable
from torch.utils.data import DataLoader
from sklearn.model_selection import KFold

from models import SpeechRecognitionModel
from utils import Get_data
from pyldl.metrics import kl_divergence, cosine


def Train(epoch, loader, model, optimizer, kl_loss_fn, cosine_weight, args):
    model.train()
    running_loss = 0.0
    for batch_idx, (data_b, target_b) in enumerate(loader, 1):
        if args.cuda:
            data_b, target_b = data_b.cuda(), target_b.cuda()
        data_b, target_b = Variable(data_b), Variable(target_b)
        optimizer.zero_grad()

        data_b = data_b.squeeze()
        log_pred = model(data_b)
        prob_pred = torch.exp(log_pred)

        loss_kl = kl_loss_fn(log_pred, target_b)
        loss_cos = 1 - F.cosine_similarity(prob_pred, target_b, dim=1).mean()
        loss = loss_kl + cosine_weight * loss_cos

        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        if batch_idx % args.log_interval == 0:
            avg = running_loss / args.log_interval
            print(f"Epoch {epoch} | Batch {batch_idx}/{len(loader)} | Loss {avg:.6f}")
            running_loss = 0.0


def evaluate(loader, model, args):
    model.eval()
    preds, trues = [], []
    with torch.no_grad():
        for data_b, target_b in loader:
            if args.cuda:
                data_b, target_b = data_b.cuda(), target_b.cuda()
            data_b = data_b.squeeze()
            log_pred = model(data_b)
            prob_pred = torch.exp(log_pred)
            preds.append(prob_pred.cpu().numpy())
            trues.append(target_b.cpu().numpy())

    y_pred = np.vstack(preds)
    y_true = np.vstack(trues)
    kl_score = kl_divergence(y_true, y_pred)
    cos_score = cosine(y_true, y_pred)
    return kl_score, cos_score, y_pred, y_true


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="2-Fold Cross-Validation on Gender Split Data")
    parser.add_argument('--cuda', action='store_false')
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--log_interval', type=int, default=10)
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--optim', type=str, default='Adam')
    parser.add_argument('--seed', type=int, default=1111)
    parser.add_argument('--cosine_weight', type=float, default=0.3)
    parser.add_argument('--input_pkl', type=str, required=True)
    parser.add_argument('--output_dir', type=str, required=True)
    args = parser.parse_args()

    torch.manual_seed(args.seed)

    with open(args.input_pkl, 'rb') as f:
        full_data = pickle.load(f)  # [male_data, female_data]

    gender_list = ['male', 'female']

    for gender_idx, gender_data in enumerate(full_data):
        gender_name = gender_list[gender_idx]
        print(f"\n===== Gender: {gender_name.upper()} =====")
        kf = KFold(n_splits=2, shuffle=True, random_state=args.seed)

        for fold_idx, (train_idx, test_idx) in enumerate(kf.split(gender_data)):
            print(f"\n--- Fold {fold_idx} for {gender_name} ---")

            train_data = [gender_data[i] for i in train_idx]
            test_data = [gender_data[i] for i in test_idx]

            train_loader, _, _, _ = Get_data(full_data, train_data, train_data, args)
            _, test_loader, test_ids, test_labels = Get_data(full_data, train_data, test_data, args)

            model = SpeechRecognitionModel(args)
            if args.cuda:
                model = model.cuda()
            optimizer = getattr(torch.optim, args.optim)(model.parameters(), lr=args.lr)
            kl_loss_fn = torch.nn.KLDivLoss(reduction='batchmean')

            for epoch in range(1, args.epochs + 1):
                Train(epoch, train_loader, model, optimizer, kl_loss_fn, args.cosine_weight, args)

            test_kl, test_cos, preds, trues = evaluate(test_loader, model, args)
            print(f"Test KL: {test_kl:.4f} | Cosine: {test_cos:.4f}")

            # 保存预测结果
            result = []
            for id_, true_, pred_ in zip(test_ids, test_labels, preds):
                result.append({'id': id_, 'True_label': true_, 'Predict_label': pred_})

            os.makedirs(args.output_dir, exist_ok=True)
            out_path = os.path.join(args.output_dir, f"Final_result_{gender_name}_fold{fold_idx}.pickle")
            with open(out_path, 'wb') as f:
                pickle.dump(result, f)

            print(f"✅ Saved result: {out_path}")
