#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 15:10:17 2019

@author: jdang03
"""

import pickle
import numpy as np 
from pyldl.metrics import (
    chebyshev, clark, canberra, kl_divergence,
    cosine, intersection
)

with open('/home/Shi22/nas01home/Cooperation/Xingfeng/Mix_Emo/SSL/Hubert-large/Final_result.pickle', 'rb') as file:
    final_result =pickle.load(file)

           
true_label = []    
predict_label = []   
num = 0
for i in range(len(final_result)):
    for j in range(len(final_result[i])):
        num = num +1
        predict_label.append(final_result[i][j]['Predict_label'])
        true_label.append(final_result[i][j]['True_label'])
print(num)            

# 转换为 numpy 数组
predict_np = np.array([x for x in predict_label])
true_np = np.array(true_label)


# 计算并打印六个指标
print(f"{'Chebyshev (↓)':22}: {chebyshev(true_np, predict_np):.4f}")
print(f"{'Clark (↓)':22}: {clark(true_np, predict_np):.4f}")
print(f"{'Canberra (↓)':22}: {canberra(true_np, predict_np):.4f}")
print(f"{'KL Divergence (↓)':22}: {kl_divergence(true_np, predict_np):.4f}")
print(f"{'Cosine Similarity (↑)':22}: {cosine(true_np, predict_np):.4f}")
print(f"{'Intersection (↑)':22}: {intersection(true_np, predict_np):.4f}")

print("Example predicted:", predict_np[0])
print("Example true     :", true_np[0])