import pickle
import numpy as np
from pyldl.metrics import (
    chebyshev, clark, canberra, kl_divergence,
    cosine, intersection
)

# === 四折文件路径 ===
base_path = "/home/shixiaohan-toda/Desktop/Cooperation/LXF/Mix_Emo_Corpora/SSL-1/MBTI/Whisper-large"
fold_paths = [f"{base_path}/Final_result_male_fold{i}.pickle" for i in range(4)]

# === 用于整体统计 ===
all_predict = []
all_true = []

# === 每一折结果 ===
for path in fold_paths:
    with open(path, 'rb') as file:
        fold_result = pickle.load(file)
    
    predict_label = [sample['Predict_label'] for sample in fold_result]
    true_label = [sample['True_label'] for sample in fold_result]
    
    predict_np = np.array(predict_label)
    true_np = np.array(true_label)

    all_predict.append(predict_np)
    all_true.append(true_np)
    
    # 打印当前折结果
    metrics = [
        chebyshev(true_np, predict_np),
        clark(true_np, predict_np),
        canberra(true_np, predict_np),
        kl_divergence(true_np, predict_np),
        cosine(true_np, predict_np),
        intersection(true_np, predict_np)
    ]
    print(",".join([f"{x:.4f}" for x in metrics]))

# === 整体结果 ===
predict_all = np.vstack(all_predict)
true_all = np.vstack(all_true)

overall_metrics = [
    chebyshev(true_all, predict_all),
    clark(true_all, predict_all),
    canberra(true_all, predict_all),
    kl_divergence(true_all, predict_all),
    cosine(true_all, predict_all),
    intersection(true_all, predict_all)
]

print(",".join([f"{x:.4f}" for x in overall_metrics]))
