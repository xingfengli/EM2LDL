import pickle
import numpy as np 
from pyldl.metrics import (
    chebyshev, clark, canberra, kl_divergence,
    cosine, intersection
)

# 自动生成四折文件路径
base_path = "/home/Shi22/nas01home/Cooperation/Xingfeng/Mix_Emo/SSL/MBTI/Hubert-large-Eng"
fold_paths = [f"{base_path}/Final_result_male_fold{i}.pickle" for i in range(4)]

# 遍历每一折
for path in fold_paths:
    with open(path, 'rb') as file:
        fold_result = pickle.load(file)
    
    predict_label = [sample['Predict_label'] for sample in fold_result]
    true_label = [sample['True_label'] for sample in fold_result]
    
    predict_np = np.array(predict_label)
    true_np = np.array(true_label)
    
    metrics = [
        chebyshev(true_np, predict_np),
        clark(true_np, predict_np),
        canberra(true_np, predict_np),
        kl_divergence(true_np, predict_np),
        cosine(true_np, predict_np),
        intersection(true_np, predict_np)
    ]
    
    print(",".join([f"{x:.4f}" for x in metrics]))
