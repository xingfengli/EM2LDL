import torch
import torch.nn as nn
from transformers import AutoProcessor, HubertModel

class SpeechRecognitionModel(nn.Module):
    def __init__(self, args):
        super(SpeechRecognitionModel, self).__init__()
        self.feature_extractor = HubertModel.from_pretrained("facebook/hubert-large-ls960-ft")
        self.out_layer = nn.Linear(1024, 32)

    def forward(self, input_waveform):
        features = self.feature_extractor(input_waveform).last_hidden_state
        mean_features = torch.mean(features, dim=1)
        logits = self.out_layer(mean_features)
        prob = nn.functional.log_softmax(logits, dim=1)  # 用 log_softmax 是为了配合 KLDivLoss
        return prob