import os
import time
import random
import argparse
import pickle
import copy
import torch
import numpy as np
import torch.nn.functional as F
from torch.autograd import Variable
from torch.utils.data import DataLoader, Dataset

from models import SpeechRecognitionModel
from pyldl.metrics import kl_divergence, cosine

# ================= Dataset and Feature =================
class subDataset(Dataset):
    def __init__(self, features, labels):
        self.features = features
        self.labels = labels

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        return torch.Tensor(self.features[idx]), torch.Tensor(self.labels[idx])

def Feature(data, args):
    input_data = [x['ssl_embedding'] for x in data]
    input_label = [x['con_label'] for x in data]
    input_id = [x['音频id'] for x in data]
    return input_data, input_label, input_id

def Get_data(_, train_data, test_data, args):
    train_features, train_labels, _ = Feature(train_data, args)
    test_features, test_labels, test_ids = Feature(test_data, args)

    train_dataset = subDataset(train_features, train_labels)
    test_dataset = subDataset(test_features, test_labels)

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, drop_last=True)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False, drop_last=False)

    return train_loader, test_loader, test_ids, test_labels

# ================= Training and Evaluation =================
def Train(epoch, loader, model, optimizer, kl_loss_fn, cosine_weight, args):
    model.train()
    running_loss = 0.0
    total_samples = 0
    for batch_idx, (data_b, target_b) in enumerate(loader, 1):
        if args.cuda:
            data_b, target_b = data_b.cuda(), target_b.cuda()
        data_b, target_b = Variable(data_b), Variable(target_b)
        optimizer.zero_grad()

        data_b = data_b.squeeze()
        log_pred = model(data_b)
        prob_pred = torch.exp(log_pred)

        loss_kl = kl_loss_fn(log_pred, target_b)
        loss_cos = 1 - F.cosine_similarity(prob_pred, target_b, dim=1).mean()
        loss = loss_kl + cosine_weight * loss_cos

        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        total_samples += data_b.size(0)

        if batch_idx % args.log_interval == 0:
            avg = running_loss / args.log_interval
            print(f"Epoch {epoch} | Trained Samples: {total_samples} | Loss {avg:.6f}")
            running_loss = 0.0

def evaluate(loader, model, args):
    model.eval()
    preds, trues = [], []
    with torch.no_grad():
        for data_b, target_b in loader:
            if args.cuda:
                data_b, target_b = data_b.cuda(), target_b.cuda()
            data_b = data_b.squeeze()
            log_pred = model(data_b)
            prob_pred = torch.exp(log_pred)
            preds.append(prob_pred.cpu().numpy())
            trues.append(target_b.cpu().numpy())

    y_pred = np.vstack(preds)
    y_true = np.vstack(trues)
    kl_score = kl_divergence(y_true, y_pred)
    cos_score = cosine(y_true, y_pred)
    return kl_score, cos_score, y_pred, y_true

# ================= Main =================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="2-Fold Pre-Split Cross-Validation")
    parser.add_argument('--cuda', action='store_false')
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--log_interval', type=int, default=10)
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--optim', type=str, default='Adam')
    parser.add_argument('--seed', type=int, default=1111)
    parser.add_argument('--cosine_weight', type=float, default=0.3)
    args = parser.parse_args()

    torch.manual_seed(args.seed)

    # ===== 手动设置路径 =====
    input_pkl = "/home/shixiaohan-toda/Desktop/Cooperation/LXF/Mix_Emo_Corpora/Database/Age/youth_SSL_Whisper-base.pickle"
    output_dir = "/home/shixiaohan-toda/Desktop/Cooperation/LXF/Mix_Emo_Corpora/SSL-1/Age/Whisper-base"

    with open(input_pkl, 'rb') as f:
        full_data = pickle.load(f)  # full_data = list of folds: each fold = [train_data, test_data]

    gender_name = 'male'
    print(f"\n===== Gender: {gender_name.upper()} =====")

    for fold_idx in range(2):
        print(f"\n--- Fold {fold_idx} ---")
        test_data = full_data[fold_idx]
        train_data = full_data[1 - fold_idx]  # 剩下那一折

        train_loader, test_loader, test_ids, test_labels = Get_data(None, train_data, test_data, args)
        
        model = SpeechRecognitionModel(args)
        if args.cuda:
            model = model.cuda()
        optimizer = getattr(torch.optim, args.optim)(model.parameters(), lr=args.lr)
        kl_loss_fn = torch.nn.KLDivLoss(reduction='batchmean')

        best_kl, best_cos = float('inf'), -float('inf')
        best_result = None

        for epoch in range(1, args.epochs + 1):
            Train(epoch, train_loader, model, optimizer, kl_loss_fn, args.cosine_weight, args)
            test_kl, test_cos, preds, trues = evaluate(test_loader, model, args)
            print(f"Test KL: {test_kl:.4f} | Cosine: {test_cos:.4f}")

            if (test_kl < best_kl) or (test_kl == best_kl and test_cos > best_cos):
                best_kl, best_cos = test_kl, test_cos
                best_result = []
                for id_, true_, pred_ in zip(test_ids, test_labels, preds):
                    best_result.append({'id': id_, 'True_label': true_, 'Predict_label': pred_})

        if best_result is not None:
            os.makedirs(output_dir, exist_ok=True)
            out_path = os.path.join(output_dir, f"Final_result_{gender_name}_fold{fold_idx}.pickle")
            with open(out_path, 'wb') as f:
                pickle.dump(best_result, f)
            print(f"✅ Saved best result: {out_path}")