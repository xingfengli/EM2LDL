#!/bin/bash
#SBATCH -n 1
#SBATCH -N 1
#SBATCH --gres=gpu:1
#SBATCH --exclude=compute02,compute01,mrcompute01
#SBATCH -t 1-00:00:00

# 初始化 conda 环境
source /home/Shi22/nas01home/anaconda3/etc/profile.d/conda.sh

# 激活虚拟环境
conda activate database

# 运行你的 Python 脚本
python -u train.py
